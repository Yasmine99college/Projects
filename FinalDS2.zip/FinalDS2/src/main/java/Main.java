import java.util.Scanner;
/**
 *
 * @author Mirna
 */
public class Main {
   public static void main(String[] args){
       //-------ESSENTIAL-------// 
       boolean play = true;
        Methods method = new Methods();
       //-------------MAZE-----------//
       boolean Maze [][];
      //--------LINKEDIN-----------// 
      boolean GRAPH [][];
      int src,gk;
      boolean[][] clone;
      
        while (play)
  {         
      System.out.print(" Please choose a Part!\n 1-linkedin 2-maze 3-City route 4-Exit");
      Scanner scan = new Scanner(System.in);
       int x = scan.nextInt();
      switch(x)
      {  
          case 1:
               Scanner sc = new Scanner(System.in);
        System.out.println("please enter number of vertices:");
       int nodes = sc.nextInt();
       GRAPH = new boolean[nodes+1][nodes+1];
        System.out.println("please enter number of edges: ");
       int edges = sc.nextInt();
        System.out.println("please enter edges in the form (u  v): ");
        for (int i = 0; i < edges; i++) {
            int s=sc.nextInt(),d=sc.nextInt();
            GRAPH[s][d]= GRAPH[d][s] = true;
        }
        System.out.println("please enter starting vertex: ");
        int node = sc.nextInt();
        src = node;
        System.out.println("please enter value k : ");
        int k =sc.nextInt();
        gk = k;
        clone = method.clone(GRAPH);
        
   System.out.printf("There are %d people with %d connections away starting from %d\n",method.solve(clone,node, k),k,node);
        
              
              break;
          case 2:
                 int n;
                 Scanner scan1 = new Scanner(System.in);
                 Scanner scan2 = new Scanner(System.in);
                 System.out.println("Please enter The Size Of Maze");
                  n = scan1.nextInt();
                  boolean[][] maze = new boolean [n][n];
                for (int i = 0; i < n; i++)
                     {
                         for (int j = 0; j < n; j++)
                               { 
                                   maze[i][j] = scan2.nextInt()==1;             
                               }
                     } 
      
                   System.out.println("Solution :");
                  method.solveMaze(maze, 0, 0, n);
                
          
           break;
          case 3:
              
              
              break;
          case 4: 
              play=false;
             break;
      }
       
    
   } 
}
}

