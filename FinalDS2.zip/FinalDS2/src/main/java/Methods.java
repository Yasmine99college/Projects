
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Mirna
 */
public class Methods {

public void printMaze(boolean[][] maze, int n){
    System.out.println("Your Matrix is : ");
        
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                System.out.print(maze[i][j]+"\t");
            }
             
            System.out.println();
        }
  } 
 ArrayList<String> ar = new ArrayList<>(); 
 boolean finish = false;

   public void solveMaze(boolean [][] Maze,int i,int j,int N)
   { 
       if(finish)
       {
           return; 
       }
	        if(Maze[i][j]) 
                {
                    return ;
                }//arg3 lel call elly ablik
	        if(i==N-1 && j==N-1) //we're in the last cell
                {
	        ar.add("("+i+","+j+")"); 
                
	        System.out.println(ar.toString().replaceAll("[\\[\\]\\s+]","")); 
	        finish = true;
	        return ;
	        }
                //make our position locked so we can't go back
	        Maze[i][j] = true;
                //add it
	        ar.add("("+i+","+j+")");
                //as the i and j change "our new step" we check if the next move is valid
                // to solve el shit bta3 aktr mn solution .. 3malt priority lel moves 
                //ye2dar still yemshy fi sekka blocked bs byfdl yerga3 fi el i wel j l7ad a5er position msh locked
                //test and see
	        if(i>0)   {solveMaze(Maze,i-1,j,N);}//up
	        if(j<N-1) {solveMaze(Maze,i,j+1,N);}//right
	        if(i<N-1) {solveMaze(Maze,i+1,j,N);}//down
	        if(j>0)   {solveMaze(Maze,i,j-1,N);}//left
                //to remove el paths elly meshy fiha w rg3 
                //brdo comment it w shofo el far2
	        ar.remove(ar.size()-1);
	     }
    boolean GRAPH [][];
      int src,gk;
      boolean[][] clone;
   //WE CREATE A CLONE OF THE GRAPH 3SHAN NEL3AB FIH BRA7ETNA FI EL TRUE W EL FALSE
   public boolean[][] clone(boolean [][] graph){
       boolean[][] clone = new boolean[graph.length][graph[0].length];
       for (int i = 0; i < clone.length; i++) 
           for (int j = 0; j < clone.length; j++) 
               clone[i][j] = graph[i][j];
           

       return clone;
   }
   public int solve(boolean [][] clone,int node,int k){
     
   if(k==0 )
   { return 1;}
            int n =0;
        for (int i = 1; i < clone.length; i++) {
            if((clone[node][i] || clone[i][node]) ){
                clone[node][i] = clone[i][node] = false;
                n+= solve(clone,i,k-1);
                clone[node][i] = clone[i][node] = true;
            }
        }
        return n;
        
    }
   }

 

