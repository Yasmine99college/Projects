/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bus.station4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author user
 */
//mno l class fih haga shabah l chose trip lel passenger 3n try2 button cancel trip
public class SceneAddTrips {

    Stage stage;
    Scene scene;
    SaveLists saveTrips;
    SceneAddDrivers addDname;
  
    SceneOne one;
    RemoveTrip removeT;
    public void prepareScene(SaveLists save) {
        saveTrips = save;
        int i;
        Label label = new Label();
        label.setText("Enter the Trips Information");

        TextField tSource = new TextField();
        tSource.setPromptText("Source"); // same as Label
        TextField tDestination = new TextField();
        tDestination.setPromptText("Destination"); // same as Label
        TextField tDate = new TextField();
        tDate.setPromptText("Date"); // same as Label
        TextField tTime = new TextField();
        tTime.setPromptText("Time"); // same as Label
       // TextField sSeats = new TextField();
       // sSeats.setPromptText("seats");
        Button add = new Button("Add");
        Button back = new Button("Back to main page");
        Button addD = new Button("add driver");
        Button remove = new Button("remove trip"); //hyft7 wimdow el remove

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(60, 60, 60, 60));
        grid.setVgap(5);
        grid.setHgap(10);
        grid.add(label, 0, 0);
        grid.add(tSource, 0, 1);
        grid.add(tDestination, 0, 2);
        grid.add(tDate, 0, 3);
        grid.add(tTime, 0, 4);
      //  grid.add(sSeats, 0, 5);
        grid.add(add, 0, 5);
        grid.add(back, 0, 6);
        grid.add(addD, 0, 7);
        grid.add(remove, 1, 8);

        scene = new Scene(grid, 500, 500);

        add.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {

                //saveTrips = new SaveLists();
                Trips trips2 = new Trips(); // creating nrew trip
                trips2.setSource(tSource.getText());
                trips2.setDestination(tDestination.getText());
                trips2.setDate(tDate.getText());
                trips2.setTime(tTime.getText());
              //  trips2.setTime(sSeats.getText());

                try {
                    saveTrips.saveTrips(trips2); // object of saveList thats calls the method that saves the trips 

                } catch (IOException ex) {

                }

            }

        });
        back.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {

                stage.setScene(one.getScene());

            }

        });
        addD.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {

                stage.setScene(addDname.getScene());

            }

        });
                 remove.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
Trips trips2 = new Trips();   //a3tkd 8lt 34n 3iza ams7 mn l fatet ana mesh a3ml gdid
                stage.setScene(removeT.getScene()); // will go to the menu
try {
                    saveTrips.saveTrips(trips2); // object of saveList thats calls the method that saves the trips 

                } catch (IOException ex) {

                }

            }
        });
               

                
            

        

    }

    public Scene getScene() {
        return scene;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setSave(SaveLists save) {
        this.saveTrips = new SaveLists();
        this.saveTrips = saveTrips;
    }

    public void setOne(SceneOne one) {
        this.one = one;
    }
     public void setOne(RemoveTrip removeT) {
        this.removeT = removeT;
    }
     public void setaddDriver(SceneAddDrivers addDname) {
        this.addDname = addDname;
    }

}
