package bus.station4;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class SceneAddDrivers {

    Stage stage;
    Scene scene;
    Drivers saveDrivers;
   SceneAddTrips addTrips;
    SceneOne one;

    public void prepareScene(Drivers save) {
        saveDrivers = save;
        int i;
        Label label = new Label();
        label.setText("Enter the drivers Information");

        TextField dName = new TextField();
        dName.setPromptText("name"); // same as Label

        Button add = new Button("Add");
    Button back = new Button("Back to main page");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(60, 60, 60, 60));
        grid.setVgap(5);
        grid.setHgap(10);
        grid.add(label, 0, 0);
        grid.add(dName, 0, 1);
  
        grid.add(add, 0, 5);
        grid.add(back, 0, 6);

        scene = new Scene(grid, 500, 500);

        add.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {

                //saveTrips = new SaveLists();
                Drivers_s drivers2 = new Drivers_s(); // creating nrew trip
                drivers2.setName(dName.getText());  //b3mlha setName ydyni error!!

                try {
                    saveDrivers.saveDriver(drivers2); // object of saveList thats calls the method that saves the trips 

                } catch (IOException ex) {

                }

            }

        });
      back.setOnAction(new EventHandler<ActionEvent>() {
           public void handle(ActionEvent event) {
               stage.setScene(one.getScene());

           }
        });

        

    }

    public Scene getScene() {
        return scene;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setSave(SaveLists save) {
        this.saveDrivers = new Drivers();
        this.saveDrivers = saveDrivers;
    }

    public void setOne(SceneOne one) {
       this.one = one;
  }
//     public void setOne(RemoveTrip removeT) {
//        this.removeT = removeT;
//    }

}
