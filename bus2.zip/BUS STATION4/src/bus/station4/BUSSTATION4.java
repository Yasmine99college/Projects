package bus.station4;

import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;

public class BUSSTATION4 extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException, FileNotFoundException, ClassNotFoundException {

        SceneOne newScene = new SceneOne(); //obj from the scene i am going to 
        SceneTwoPassenger passenger = new SceneTwoPassenger(); //obj from the scene i am going to 
        SceneTwoManager manager = new SceneTwoManager(); //obj from the scene i am going to 
        SceneTwoDriver driver = new SceneTwoDriver(); //obj from the scene i am going to 
        SceneAddTrips addTrips = new SceneAddTrips();
        Validation V = new Validation();
        SaveLists save = new SaveLists();// to take from the class 
        Drivers_s saveD = new Drivers_s();
        save.load();
       // saveD.load2();
        ScenePassengerProfile passengerProfile = new ScenePassengerProfile();

        manager.setAddTrips(addTrips);
        newScene.setStage(primaryStage); // the same stage 
        passenger.setStage(primaryStage); // the same stage 
        manager.setStage(primaryStage); // the same stage 
        driver.setStage(primaryStage); // the same stage 
        
        addTrips.setStage(primaryStage);

        newScene.prepareScene();
        driver.prepareScene();
        manager.prepareScene();
        passenger.prepareScene();
        addTrips.prepareScene(save);
        passengerProfile.prepareScene(save);
        //passengerProfile.setLists(save);
        //addTrips.setSave(save);

        newScene.setDriver(driver);
        newScene.setManager(manager);
        newScene.setPassenger(passenger);
        newScene.setAddTrips(addTrips);
        newScene.setSave(save);
        manager.setAddTrips(addTrips);
        manager.setV(V);
        driver.setV(V);
        passenger.setV(V);
        passenger.setPassengerProfile(passengerProfile);

        passengerProfile.setLists(save);
        addTrips.setOne(newScene);
        addTrips.setStage(primaryStage); // the same stage
        passengerProfile.setLists(save);

        primaryStage.setScene(newScene.getScene());

        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

}
