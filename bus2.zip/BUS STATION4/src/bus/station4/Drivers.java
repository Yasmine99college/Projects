package bus.station4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
//class like saveLists to do drivers list

public class Drivers {
//

    SceneTwoManager manager;
   // ScenePassengerProfile ScenePassengerProfile;
//
    ArrayList<Drivers_s> driver = new ArrayList<Drivers_s>(); // the name of the class to know what to store 
//

    public ArrayList<Drivers_s> getDrivers() { // to use this list in another class
        return driver;
    }
//

    public void saveDriver(Drivers_s d) throws FileNotFoundException, IOException {

        driver.add(d);
//        // save to file
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("newdriver.txt")); // opens the file to save in it 
//
        int size = driver.size(); // to know the size of the arraylsit 
        int i = 0;
        while (i < size) { // saves in file 
//
            Drivers_s a = driver.get(i); // gets the trips in index i and put in a
            out.writeObject(a); // write in file 
//
            i++;
        }
        out.close();
        check();
//
//        // end save to file 
    }
//

    public void load2() throws FileNotFoundException, IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("newdriver.txt"));
        while (true) {
            int i = 0;
            try {
                driver.add((Drivers_s) in.readObject()); //load to the file 
//                System.out.println(driver.get(0).name);
////                System.out.println(driver.get(i).destination);
////                System.out.println(driver.get(0).date);
//                //i++;
//
            } catch (java.io.EOFException eoe) {
                break;
            }
//
        }
//
    }
//

    public void check() {
        int i = 0;
        int s = driver.size();
        System.out.println(driver.size());
        while (i < s) {
            System.out.println(driver.get(i).name);
//           
            i++;
//            
        }
    }
//
}
//
