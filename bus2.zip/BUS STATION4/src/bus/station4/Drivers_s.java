package bus.station4;

import java.io.Serializable;
//class like trips
public class Drivers_s implements Serializable {// any class ill save its object ill use serializable 

    String name;
    
    public Drivers_s(String name) {
        this.name = name;
      
    }

    public Drivers_s() {
    }

    public void setName(String source) {
        this.name = name;
    }

    void load() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
}

