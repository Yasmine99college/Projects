/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bus.station4;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.omg.CORBA.BAD_CONTEXT;
//ytnada f zorar l removetrip
/**
 *
 * @author user
 */
public class RemoveTrip {

    Scene scene;
    Stage stage;
    SaveLists lists;
    int i =0;

    public void prepareScene(SaveLists save) {
        lists = save;
        Label source = new Label();
        Label destination = new Label();
        Label date = new Label();
        Label time = new Label();
        Button removechanges = new Button("remove");
        Button prev = new Button("prev");
         
         Button next=new Button ("next");
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(60, 60, 60, 60));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.add(source, 0, 1);
        grid.add(destination, 2, 1);
        grid.add(date, 3, 1);
        grid.add(time, 4, 1);
        grid.add(next, 5, 1);
        grid.add(prev, 6, 1);
        grid.add(removechanges, 7, 1);
        
        
        
        next.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
              
                ArrayList<Trips> newlist = lists.getTrips();
               // System.out.println(newlist.size());
               if(i == -1)
                   i = i+1;
               if(i>= newlist.size())
                   return;
                Trips trip = newlist.get(i);
                
                source.setText(trip.source);
                destination.setText(trip.destination);
                date.setText(trip.date);
                time.setText(trip.Time);
                //time.setText(trip.seats);
                i++;
            }
            
        });
          prev.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
              
                ArrayList<Trips> newlist = lists.getTrips();
               // System.out.println(newlist.size());
               if(i == newlist.size())
                   i = i-2;
               if(i<= -1)
                   return;
                Trips trip = newlist.get(i);
               
                source.setText(trip.source);
                destination.setText(trip.destination);
                date.setText(trip.date);
                time.setText(trip.Time);
              //  time.setText(trip.seats);
                i--;
                
            }
            
        });
          removechanges.setOnAction(new EventHandler<ActionEvent>() {
           public void handle(ActionEvent event) {
//              
               ArrayList<Trips> newlist = lists.getTrips();
//               if(i == newlist.size())
//                   i = i-2;
//               if(i<= -1)
//                   return;
//                Trips trip = newlist.get(i);
//                
//                source.setText(trip.source);
//                destination.setText(trip.destination);
//                date.setText(trip.date);
//                time.setText(trip.Time);
//                i--;
               newlist.remove(i);
        }
           
       });
          
        
        
        
        scene = new Scene(grid, 600, 400);

    }
                

    public Scene getScene() {
        return scene;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setLists(SaveLists lists) {
        this.lists = new SaveLists();
        this.lists = lists;
    }
    

}
