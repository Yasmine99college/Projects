/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bus.station4;
import java.io.Serializable;

public class Trips implements Serializable {// any class ill save its object ill use serializable 

    String source;
    String destination;
    String date;
    String Time;
    String price;
  //  String seats;
    

    public Trips(String source, String destination, String date, String Time, String price,String seats) {
        this.source = source;
        this.destination = destination;
        this.date = date;
        this.Time = Time;
        this.price = price;
        //this.seats=seats;
    }

    public Trips() {
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String Time) {
        this.Time = Time;
    }

    public void setPrice(String price) {
        this.price = price;
    }
//    public void setSeats(String seats) {
//        this.seats = seats;
//    }

}

