/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bus.station4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SaveLists {

    SceneTwoManager manager;
    ScenePassengerProfile ScenePassengerProfile;

    ArrayList<Trips> trips = new ArrayList<Trips>(); // the name of the class to know what to store 

    public ArrayList<Trips> getTrips() { // to use this list in another class
        return trips;
    }

    public void saveTrips(Trips t) throws FileNotFoundException, IOException {

        trips.add(t);
        // save to file
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("newTrips.txt")); // opens the file to save in it 

        int size = trips.size(); // to know the size of the arraylsit 
        int i = 0;
        while (i < size) { // saves in file 

            Trips a = trips.get(i); // gets the trips in index i and put in a
            out.writeObject(a); // write in file 

            i++;
        }
        out.close();
        check();

        // end save to file     
    }

    public void load() throws FileNotFoundException, IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("newTrips.txt"));
        while (true) {
            int i = 0;
            try {
                trips.add((Trips) in.readObject()); //load to the file 
//                System.out.println(trips.get(0).source);
//                System.out.println(trips.get(i).destination);
//                System.out.println(trips.get(0).date);
                //i++;

            } catch (java.io.EOFException eofe) {
                break;
            }

        }

    }

    public void check() {
        int i = 0;
        int s = trips.size();
        System.out.println(trips.size());
        while (i<s) {
            System.out.println(trips.get(i).Time);
            System.out.println(trips.get(i).source);
            System.out.println(trips.get(i).date);
            System.out.println(trips.get(i).destination);
         //   System.out.println(trips.get(i).seats);
            i++;
            
        }
    }

}
